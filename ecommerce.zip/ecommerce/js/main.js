function confirmarBorrar(){
    return confirm("Desea borrar este producto?")
}

function confirmarBorrarUsuario(){
    return confirm("Desea borrar este usuario?")
}