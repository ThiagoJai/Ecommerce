let carrito = [];
        let total = 0;

        function agregarAlCarrito(nombre, precio) {
            carrito.push({ nombre, precio });
            total += precio;
            actualizarCarrito();
        }

        function actualizarCarrito() {
            const cartContent = document.querySelector('.cart-content');
            const cartCount = document.getElementById('cart-count');
            const totalPrice = document.querySelector('.total-price');

            cartContent.innerHTML = '';
            carrito.forEach((producto, index) => {
                cartContent.innerHTML += `<p>${producto.nombre} - $${producto.precio.toLocaleString()} <button onclick="eliminarDelCarrito(${index})">Eliminar</button></p>`;
            });

            cartCount.innerText = carrito.length;
            totalPrice.innerText = total.toLocaleString();
        }

        function eliminarDelCarrito(index) {
            total -= carrito[index].precio;
            carrito.splice(index, 1);
            actualizarCarrito();
        }

        function toggleCart() {
            const cart = document.getElementById('cart');
            cart.style.display = (cart.style.display === 'none' || cart.style.display === '') ? 'block' : 'none';
        }

        function vaciarCarrito() {
            carrito = [];
            total = 0;
            actualizarCarrito();
            document.getElementById('cart').style.display = 'none';
        }


// Función para guardar el carrito en una cookie
function guardarCarritoEnCookie(carrito) {
    const carritoJSON = JSON.stringify(carrito); // Convertir el carrito en una cadena JSON
    document.cookie = `carrito=${carritoJSON}; path=/; max-age=604800`; // Guardar cookie por 7 días
  }
  
  // Función para leer el carrito desde la cookie
  function leerCarritoDeCookie() {
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
      const [nombre, valor] = cookies[i].split('=');
      if (nombre.trim() === 'carrito') {
        return JSON.parse(decodeURIComponent(valor)); // Parsear el JSON y devolverlo
      }
    }
    return []; // Si no hay carrito en la cookie, devolver un carrito vacío
  }
  