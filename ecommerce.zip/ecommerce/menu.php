<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="index.php">ComputacionYa</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="productos_teclados.php">Teclados</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="productos_PC.php">PC</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="productos_almacenamiento.php">Almacenamiento</a>
                </li>
          </ul>
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link cart-icon" id="cart-icon" href="#" onclick="toggleCart()">
                 <i class="fas fa-shopping-cart"></i>
                   <span class="cart-count" id="cart-count">0</span>
              </a>
            </li>
            <form class="d-flex me-3" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success" type="submit">Search</button>
          </form>
            <li class="nav-item">
              <a class="nav-link" href="login.php">
                <i class="fas fa-sing-in-alt"></i>
                Iniciar Sesion
              </a>
            </li>
          </ul>
      </div>
</nav>