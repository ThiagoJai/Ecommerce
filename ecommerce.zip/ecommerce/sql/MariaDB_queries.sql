-- Active: 1731507198059@@127.0.0.1@3306@tienda_v
use tienda_v;
SELECT p.nombre AS Producto, p.precio, p.stock 
FROM productos p
JOIN categorias c ON p.categoria_id = c.id
WHERE c.nombre = 'Laptops';

SELECT c.nombre AS Categoria, SUM(p.stock) AS StockTotal
FROM productos p
JOIN categorias c ON p.categoria_id = c.id
GROUP BY c.nombre;

SELECT * FROM productos WHERE nombre LIKE '%Notebook%';
SELECT * FROM productos WHERE nombre LIKE '%Laptop%';
SELECT * FROM usuarios WHERE nombre LIKE '%Juan%';
SELECT * FROM carritos WHERE usuario_id LIKE '%3%';

SELECT nombre, stock 
FROM productos 
WHERE stock < 20;

SELECT c.nombre AS Categoria, p.nombre AS Producto, MAX(p.precio) AS Precio
FROM productos p
JOIN categorias c ON p.categoria_id = c.id
GROUP BY c.nombre;

SELECT SUM(c.cantidad) AS total_articulos
FROM carritos c
WHERE c.usuario_id = 1;


SELECT c.nombre AS categoria, COUNT(p.id) AS total_productos
FROM categorias c
LEFT JOIN productos p ON c.id = p.categoria_id
GROUP BY c.nombre;

UPDATE productos SET stock = stock - 1 WHERE id = 1 AND stock > 0;

SELECT p.nombre AS producto, c.nombre AS categoria, p.precio, p.stock
FROM productos p
JOIN categorias c ON p.categoria_id = c.id; 

SELECT c.cantidad, p.nombre AS producto
FROM carritos c
JOIN productos p ON c.producto_id = p.id
JOIN usuarios u ON c.usuario_id = u.id
WHERE u.nombre = 'Ana Gómez';