-- Active: 1731507198059@@127.0.0.1@3306@tienda_v
drop database if exists tienda_v;
create database tienda_v;
use tienda_v;

ALTER TABLE usuarios ADD COLUMN role ENUM('admin', 'user') NOT NULL DEFAULT 'user';
UPDATE usuarios SET role = 'admin' WHERE correo = 'juan.perez20@example.com';

create table usuarios(
    id integer AUTO_INCREMENT,
    nombre varchar(25) not null,
    correo varchar(50) not null,
    password varchar(50) null,
    primary key(id)
);

create table categorias(
    id integer AUTO_INCREMENT,
    nombre varchar(50) not null,
    descripcion text,
    primary key(id)
);

create table productos(
    id integer AUTO_INCREMENT,
    categoria_id int not null,
    nombre varchar(50) not null,
    precio varchar(100) not null,
    stock int,
    foreign key(categoria_id) references categorias(id),
    primary key (id)
);

create table carritos(
    id integer AUTO_INCREMENT,
    usuario_id int not null,
    producto_id int not null,
    cantidad int not null,
    foreign key(usuario_id) references usuarios(id) on delete cascade,
    foreign key(producto_id) references productos(id),
    primary key(id)
);

create table imagenes_productos(
    id integer AUTO_INCREMENT,
    producto_id int not null,
    url_imagen varchar(200) not null,
    foreign key(producto_id) references productos(id) on delete cascade,
    primary key(id)
); 

create table ordenes(
    id integer AUTO_INCREMENT primary key,
    usuario_id int not null,
    total decimal(10,2) not null,
    estado ENUM('pendiente', 'enviado', 'entregado', 'cancelado') default 'pendiente',
    creado_en timestamp default CURRENT_TIMESTAMP,
    foreign key(usuario_id) references usuarios(id)
);

CREATE TABLE metodos_pago (
    id integer AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    numero_tarjeta VARCHAR(16) NOT NULL,
    fecha_expiracion DATE NOT NULL,
    cvv VARCHAR(3) NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

