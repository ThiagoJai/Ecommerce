<?php
function checkSession(){
    session_start();
    if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!== true){
        header('Location: /public/login.php');
        exit();
    }
}

function checkAdmin(){
    checkSession();
    if($_SESSION['role'] != 'admin'){
        echo"Acceso denegado.";
        exit();
    }
}
?>