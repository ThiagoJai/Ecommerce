<?php ini_set("display_errors", "1"); ?>
<?php
include_once "php/connectors/connector.php";
if(
    isset(($_REQUEST['categoria_id'])) && $_REQUEST['categoria_id'] != '' &&
    isset($_REQUEST['nombre']) && $_REQUEST['nombre'] != '' 
){
    $categoria_id = $_REQUEST['categoria_id'];
    $nombre = $_REQUEST['nombre'];
    $precio = $_REQUEST['precio'];
    $stock = $_REQUEST['stock'];

    $tabla = "productos";
    $campos = "categoria_id, nombre, precio, stock";
    $value = "'".$categoria_id."','".$nombre."','".$precio."','".$stock."'";
    $connector = new Connector();
    $connector->insert($tabla, $campos, $value);
    echo "Se ha ingresado un nuevo producto";
}else{
    echo"Por favor ingrese un nuevo producto";
}
?>