<?php ini_set("display_errors", "1"); ?>
<?php
include_once "php/connectors/connector.php";
if(
    isset($_REQUEST['usuario_id']) && $_REQUEST['usuario_id'] != '' &&
    isset($_REQUEST['producto_id']) && $_REQUEST['producto_id'] != ''
){
    $usuario_id = $_REQUEST['usuario_id'];
    $producto_id = $_REQUEST['producto_id'];
    $cantidad = $_REQUEST['cantidad'];

    $tabla = "carritos";
    $campos = "usuario_id, producto_id, cantidad";
    $value = "'". $usuario_id."','". $producto_id. "','". $cantidad."'";
    $connector = new Connector();
    $connector->insert($tabla, $campos,$value);
    echo "Se ha ingresado un nuevo carrito";
}else{
    echo "Por favor ingrese un nuevo carrito";
}
?>