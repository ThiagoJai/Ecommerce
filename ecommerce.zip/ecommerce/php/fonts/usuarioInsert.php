<?php ini_set("display_errors", "1");?>
<?php
include_once "php/connectors/connector.php";
if(
    isset($_REQUEST['nombre']) && $_REQUEST['nombre'] != '' &&
    isset($_REQUEST['correo']) && $_REQUEST['correo'] != ''
){
    $nombre = $_REQUEST['nombre'];
    $correo = $_REQUEST['correo'];
    $password = $_REQUEST['password'];

    $tabla = "usuarios";
    $campos = "nombre, correo, password";
    $value = "'".$nombre."','".$correo."','".$password."'";
    $connector = new Connector();
    $connector->insert($tabla, $campos, $value);
    echo "Se ha ingresado un nuevo usuario";
}else{
    echo "Por favor ingrese un nuevo usuario";
}
?>