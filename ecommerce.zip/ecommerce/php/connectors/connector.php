<?php
class Connector{
    public function getConnector(){
        //PDO:mariadb://localhost:3306/tienda_v

        $driver='mysql';
        $hostname='localhost';
        $username='root';
        $password='';
        $base='tienda_v';
        return new PDO("$driver:host=$hostname;dbname=$base", $username, $password);
    }

    public function getData(){
        return "Maria DB 10";
    }

    public function insert($tabla, $campos, $values){
        $sql="insert into $tabla ($campos) values ($values)";
        return $this->getConnector()->exec($sql);
    }

    public function delete($tabla, $filtro){
        $sql="delete from $tabla where $filtro";
        return $this->getConnector()->exec($sql);
    }

    public function update($tabla, $set, $filtro){
        $sql="update $tabla set $set where $filtro";
        return $this->getConnector()->exec($sql);
    }

    public function get($tabla, $filtro){
        $sql = "select * from $tabla where $filtro";
        return $this->getConnector()->query($sql);
    }

    public function getAll($tabla){
        return $this->get($tabla, "1=1");
    }
}
?>