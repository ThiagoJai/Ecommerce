<?php

session_start();
if () {
    $_SESSION['redirect_to'] = $_SERVER['REQUEST_URI'];
    header('Location: /index.php');
    exit();
}else

// session_start();

// $usuario = $_POST['usuario'];
// $password = $_POST['password'];

// // Consulta para verificar el usuario
// $query = "SELECT * FROM usuarios WHERE correo='$usuario' AND password='$password'";
// $result = mysqli_query($conn, $query);

// if (mysqli_num_rows($result) > 0) {
//     $row = mysqli_fetch_assoc($result);

//     // Guarda la información del usuario en la sesión
//     $_SESSION['usuario'] = $usuario;
//     $_SESSION['role'] = $row['role'];

//     // Redirigir según el rol del usuario
//     if ($row['role'] == 'admin') {
//         header('Location: deshboard.php'); // Redirigir al panel de administración
//     } else {
//         header('Location: index.php'); // Redirigir a la página principal
//     }
//     exit();
// } else {
//     echo "Usuario o contraseña incorrectos";
// }

?> 